<html>
<head>
<title>Thank You page</title>
<link rel="stylesheet" type="text/css" href="indexcss.css">
</head>
<body>
<div align="center" style="margin: 10%">
<p style="color:red">Your account has been created....</p>
<h3 style="color:white">
Thank You for joining <strong>Technaman</strong> programming word !!!
</h3>
<button type="button"><a href="login.php">Log IN Here</a></button>
</div>
</body>
</html>