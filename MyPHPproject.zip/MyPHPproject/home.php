<?php
   session_start();
   if(!isset($_SESSION["username"]))
   {
    header("location: login.php");
    exit;
   }
?>
<html>
<head>
<title>Home Page</title>
<link rel="stylesheet" type="text/css" href="homestyle.css">
</head>
<body>
<script>
document.querySelector('.button').addEventListener('click', () => {
  document.querySelector('.content').classList.toggle('isOpen');
});
</script>
<div class="wrapper">
  <div class="sidebar">
    <ul class="nav">
      <li><a>Dashboard</a></li>
      <li><a class="active" href="#">Home</a></li>
      <li><a href="aboutus.php">About</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="logout.php">Logout</a></li>
    </ul>
  </div>
  <div class="content isOpen">
    <a class="button">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
        <line x1="0" y1="20" x2="100" y2="20" />
        <line x1="0" y1="50" x2="100" y2="50" />
        <line x1="0" y1="80" x2="100" y2="80" />
      </svg>
    </a>
    <h1><i>TechNaman</i></h1><br><br>
	<p>This is a simple web page designed by Naman Tiwari for the Viva College Web project</p>
  </div>
</div>
</body>
</html>