<?php
    $db = mysqli_connect("localhost","root","","myprojectdb") or die("Could not connect !!!");
	header( "refresh:2;url=home.php" );
?>
<html>
<head>
<meta charset="utf-8">
<title>Loading...</title>
	<link href="styleload.css" rel="stylesheet">
</head>
 
<body>
<h3 style="color:red">Loading please wait...</h3>
<div class="loader">
  <div class="dots"></div>
  <div class="dots"></div>
  <div class="dots"></div>
  <div class="dots"></div>
  <div class="dots"></div>
</div>
</body>
</html>