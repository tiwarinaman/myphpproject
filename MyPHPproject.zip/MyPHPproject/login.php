<?php

 
    $db = mysqli_connect("localhost","root","","myprojectdb");
 
    if(isset($_POST['login_btn']))
	{
	$username = mysqli_real_escape_string($db,$_POST['username']);  
	$password = mysqli_real_escape_string($db,$_POST['password']);  
	
	$password = md5($password);
	$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
	$result = mysqli_query($db, $sql);
		
	if(mysqli_num_rows($result)==1)
	{
		session_start();
		$_SESSION["message"] = "You are now logged in";
		$_SESSION["username"] = $username;
		header("location: loading.php");
	}
	else
	{
		$_SESSION["msg"] = "1";
	}
	}	
?>



<html>
<head>
<title>Log IN</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container loginpage">
<div class="login-box">
    <span>Login</span>
    <form method="post" action="login.php">
        <input type="text" name="username" placeholder="Username" required="required" />
        <input type="password" name="password" placeholder="Password" required="required" />
        <button type="submit" class="btn btn-primary btn-block btn-large" name="login_btn">Let me in.</button>
		<p style="color:red"
		><?php
		   if(isset($_SESSION["msg"])==1)
			   echo "You have entered a wrong username/password !!!";
		  
		?>
		</p>
    </form>
</div>
</div>
</body>
</html>