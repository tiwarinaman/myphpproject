<?php
   session_start();
   if(!isset($_SESSION["username"]))
   {
    header("location: login.php");
    exit;
   }
?>
<html>
<head>
<title>About Us</title>
<link rel="stylesheet" type="text/css" href="about.css">
</head>
<body>
<div class="container">
    <h1 align="center" style="color: lightblue">About me </h1>
</div>
<div>
<h3 style="color:white">A first year B.Sc(IT) undergraduate student at Viva college with an interest in Software development , AI , IOT and Web development.</h3>

</div>
</body>
</html>