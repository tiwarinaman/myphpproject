<?php
 $db = mysqli_connect("localhost","root","","myprojectdb");
 if(isset($_POST['register_btn']))
 {
	$username = mysqli_real_escape_string($db,$_POST['username']); 
	$email = mysqli_real_escape_string($db,$_POST['email']); 
	$password = mysqli_real_escape_string($db,$_POST['password']); 
	$password2 = mysqli_real_escape_string($db,$_POST['password2']); 

	session_start();
	
	if($password==$password2)
	{
		#$password = md5($password); //hashing password before storing it
		$sql = "INSERT INTO users(username,email,password) VALUES('$username','$email','$password')";
		mysqli_query($db,$sql);
		$_SESSION['message'] = "You are now loged in";
		$_SESSION['username'] = $username;
		header("location: thankyou.php");
	}
	else
	{
		$_SESSION['message'] = "The two password do not match";
	}
 }
?>

<html>
<head>
<title>Registration Page</title>
<link rel="stylesheet" type="text/css" href="indexcss.css">
</head>
<body>
<form method="post" action="index.php">
  <div class="container">
    <h1><i>Register New Account</i></h1>
    <p>Please fill in this form to create an account.</p>
	<hr class="text-box">
	
	<label for="username"><b></b></label>
	<input type="text" placeholder="Enter Username" name="username" required><br>
	

    <label for="email"><b></b></label>
    <input type="text" placeholder="Enter Email" name="email" required><br>

    <label for="password"><b></b></label>
    <input type="password" placeholder="Enter Password" name="password" required><br>

    <label for="password2"><b></b></label>
    <input type="password" placeholder="Repeat Password" name="password2" required><br>
    <hr>

	<p class="btn"><input type="submit" name="register_btn" value="Register"></p><br><br>
	<p>Already have an account? <a href="login.php">Sign in</a>.</p>
  </div>
</form> 
</body>
</html>